-- ============================================================
-- PATCH : corrige les erreurs 403 Forbidden sur PostgREST
-- Cause : les policies RLS existent, mais le rôle "authenticated"
-- n'a pas reçu le droit SELECT/INSERT/UPDATE/DELETE sur les tables.
-- À exécuter dans Supabase > SQL Editor.
-- ============================================================

grant usage on schema public to authenticated, anon;

grant select, insert, update, delete on
  departements,
  profiles,
  kpis,
  objectifs,
  affectations_kpi,
  saisies_kpi,
  plans_actions,
  audit_logs
to authenticated;

-- Pour toute nouvelle table créée plus tard, applique les mêmes droits automatiquement
alter default privileges in schema public
  grant select, insert, update, delete on tables to authenticated;

-- Les séquences (id auto-incrémentés) ont aussi besoin d'un accès
grant usage, select on all sequences in schema public to authenticated;
alter default privileges in schema public
  grant usage, select on sequences to authenticated;
