// Supabase Edge Function : create-user
// Déployer avec : supabase functions deploy create-user

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

Deno.serve(async (req) => {
  // Le navigateur envoie d'abord une requête OPTIONS ("preflight") :
  // il faut y répondre correctement, sinon la vraie requête POST
  // est bloquée avant même de partir.
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const authHeader = req.headers.get('Authorization') ?? ''
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!

    const callerClient = createClient(supabaseUrl, Deno.env.get('SUPABASE_ANON_KEY')!, {
      global: { headers: { Authorization: authHeader } },
    })
    const { data: { user: caller } } = await callerClient.auth.getUser()
    if (!caller) {
      return new Response('Non authentifié', { status: 401, headers: corsHeaders })
    }

    const { data: callerProfile } = await callerClient
      .from('profiles')
      .select('role')
      .eq('id', caller.id)
      .single()

    if (callerProfile?.role !== 'ADMINA') {
      return new Response('Accès refusé : réservé aux Admina', { status: 403, headers: corsHeaders })
    }

    const { username, password, nom, prenom, role, departement_id } = await req.json()

    const adminClient = createClient(supabaseUrl, serviceRoleKey)

    const { data: created, error: createError } = await adminClient.auth.admin.createUser({
      email: `${username.toLowerCase()}@socolait.local`,
      password,
      email_confirm: true,
    })
    if (createError) throw createError

    const { error: profileError } = await adminClient.from('profiles').insert({
      id: created.user.id,
      username,
      nom,
      prenom,
      role,
      departement_id,
    })
    if (profileError) throw profileError

    return new Response(JSON.stringify({ ok: true, id: created.user.id }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  } catch (err) {
    return new Response(JSON.stringify({ ok: false, error: err.message }), {
      status: 400,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }
})
