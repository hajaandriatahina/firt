-- ============================================================
-- SCHEMA KPI SOCOLAIT — Supabase (Postgres)
-- A exécuter dans Supabase > SQL Editor
-- ============================================================

-- Extension pour uuid
create extension if not exists "pgcrypto";

-- ------------------------------------------------------------
-- 1. PROFILS UTILISATEURS
-- On s'appuie sur auth.users (Supabase Auth) + une table "profiles"
-- qui stocke le rôle, le département, le username affiché, etc.
-- Comme Supabase Auth exige un email, on connecte les utilisateurs
-- avec "username@socolait.local" en interne (voir Login.jsx),
-- mais ils saisissent seulement leur "username" à l'écran.
-- ------------------------------------------------------------
create table if not exists departements (
  id            bigint generated always as identity primary key,
  nom           text not null unique,
  description   text,
  actif         boolean not null default true,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

create table if not exists profiles (
  id              uuid primary key references auth.users (id) on delete cascade,
  nom             text,
  prenom          text,
  username        text unique not null,
  role            text not null check (role in ('ADMINA','DIRECTEUR','RESPONSABLE')),
  departement_id  bigint references departements(id),
  statut          text not null default 'ACTIF',
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

-- ------------------------------------------------------------
-- 2. KPI
-- ------------------------------------------------------------
create table if not exists kpis (
  id              bigint generated always as identity primary key,
  code            text unique,
  nom             text not null,
  description     text,
  departement_id  bigint references departements(id),
  unite           text,               -- %, nombre, kg, tonne, MGA...
  frequence       text not null default 'MENSUELLE', -- JOURNALIERE / HEBDOMADAIRE / MENSUELLE
  type_valeur     text not null default 'DECIMAL',   -- DECIMAL / ENTIER
  actif           boolean not null default true,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

-- ------------------------------------------------------------
-- 3. OBJECTIFS (valables sur une période/année donnée)
-- ------------------------------------------------------------
create table if not exists objectifs (
  id              bigint generated always as identity primary key,
  kpi_id          bigint not null references kpis(id) on delete cascade,
  valeur_objectif numeric not null,
  operateur       text not null default '>=', -- >=, <=, =, <, >
  date_debut      date,
  date_fin        date,
  annee           int not null,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

-- ------------------------------------------------------------
-- 4. AFFECTATION D'UN KPI A UN RESPONSABLE
-- ------------------------------------------------------------
create table if not exists affectations_kpi (
  id              bigint generated always as identity primary key,
  utilisateur_id  uuid not null references profiles(id) on delete cascade,
  kpi_id          bigint not null references kpis(id) on delete cascade,
  date_debut      date default current_date,
  date_fin        date,
  actif           boolean not null default true,
  unique (utilisateur_id, kpi_id)
);

-- ------------------------------------------------------------
-- 5. SAISIES KPI (les résultats saisis par les Responsables)
-- ------------------------------------------------------------
create table if not exists saisies_kpi (
  id              bigint generated always as identity primary key,
  kpi_id          bigint not null references kpis(id) on delete cascade,
  utilisateur_id  uuid not null references profiles(id) on delete cascade,
  date_saisie     date not null default current_date,
  periode         text,     -- ex: '2026-S37' ou '2026-09'
  annee           int not null,
  semaine         int,
  mois            int,
  valeur          numeric not null,
  commentaire     text,
  statut          text,     -- CONFORME / NON_CONFORME (calculé côté front à l'enregistrement)
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

-- ------------------------------------------------------------
-- 6. PLANS D'ACTION
-- ------------------------------------------------------------
create table if not exists plans_actions (
  id                  bigint generated always as identity primary key,
  kpi_id              bigint references kpis(id) on delete cascade,
  saisie_kpi_id       bigint references saisies_kpi(id) on delete cascade,
  responsable_id      uuid references profiles(id),
  probleme            text,
  cause               text,
  action              text,
  responsable_action  text,
  date_debut          date,
  date_echeance       date,
  statut              text default 'EN_COURS', -- EN_COURS / TERMINE / EN_RETARD
  commentaire         text,
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now()
);

-- ------------------------------------------------------------
-- 7. AUDIT LOGS
-- ------------------------------------------------------------
create table if not exists audit_logs (
  id              bigint generated always as identity primary key,
  utilisateur_id  uuid references profiles(id),
  action          text,
  table_name      text,
  record_id       text,
  ancienne_valeur jsonb,
  nouvelle_valeur jsonb,
  created_at      timestamptz not null default now()
);

-- ============================================================
-- FONCTION UTILITAIRE : récupérer le rôle de l'utilisateur connecté
-- ============================================================
create or replace function public.current_role_name()
returns text
language sql
stable
security definer
as $$
  select role from profiles where id = auth.uid();
$$;

-- ============================================================
-- ROW LEVEL SECURITY
-- ============================================================
alter table departements    enable row level security;
alter table profiles        enable row level security;
alter table kpis            enable row level security;
alter table objectifs       enable row level security;
alter table affectations_kpi enable row level security;
alter table saisies_kpi     enable row level security;
alter table plans_actions   enable row level security;
alter table audit_logs      enable row level security;

-- Tout utilisateur connecté peut lire son propre profil + l'admin/directeur voient tout
create policy "profiles_select" on profiles for select
  using ( id = auth.uid() or current_role_name() in ('ADMINA','DIRECTEUR') );

create policy "profiles_update_self_or_admin" on profiles for update
  using ( id = auth.uid() or current_role_name() = 'ADMINA' );

create policy "profiles_insert_admin" on profiles for insert
  with check ( current_role_name() = 'ADMINA' );

create policy "profiles_delete_admin" on profiles for delete
  using ( current_role_name() = 'ADMINA' );

-- Départements & KPI & Objectifs : lecture pour tous les connectés, écriture Admin seulement
create policy "departements_select_all" on departements for select using ( auth.uid() is not null );
create policy "departements_write_admin" on departements for all
  using ( current_role_name() = 'ADMINA' ) with check ( current_role_name() = 'ADMINA' );

create policy "kpis_select_all" on kpis for select using ( auth.uid() is not null );
create policy "kpis_write_admin" on kpis for all
  using ( current_role_name() = 'ADMINA' ) with check ( current_role_name() = 'ADMINA' );

create policy "objectifs_select_all" on objectifs for select using ( auth.uid() is not null );
create policy "objectifs_write_admin" on objectifs for all
  using ( current_role_name() = 'ADMINA' ) with check ( current_role_name() = 'ADMINA' );

-- Affectations : admin gère tout, responsable voit les siennes, directeur voit tout
create policy "affectations_select" on affectations_kpi for select
  using ( utilisateur_id = auth.uid() or current_role_name() in ('ADMINA','DIRECTEUR') );
create policy "affectations_write_admin" on affectations_kpi for all
  using ( current_role_name() = 'ADMINA' ) with check ( current_role_name() = 'ADMINA' );

-- Saisies : un responsable ne voit / n'insère que ses propres saisies ; admin/directeur voient tout
create policy "saisies_select" on saisies_kpi for select
  using ( utilisateur_id = auth.uid() or current_role_name() in ('ADMINA','DIRECTEUR') );
create policy "saisies_insert" on saisies_kpi for insert
  with check ( utilisateur_id = auth.uid() or current_role_name() = 'ADMINA' );
create policy "saisies_update" on saisies_kpi for update
  using ( utilisateur_id = auth.uid() or current_role_name() = 'ADMINA' );
create policy "saisies_delete_admin" on saisies_kpi for delete
  using ( current_role_name() = 'ADMINA' );

-- Plans d'action : responsable concerné + admin/directeur
create policy "plans_select" on plans_actions for select
  using ( responsable_id = auth.uid() or current_role_name() in ('ADMINA','DIRECTEUR') );
create policy "plans_insert" on plans_actions for insert
  with check ( responsable_id = auth.uid() or current_role_name() = 'ADMINA' );
create policy "plans_update" on plans_actions for update
  using ( responsable_id = auth.uid() or current_role_name() = 'ADMINA' );

-- Audit logs : lecture admin seulement, écriture par tous (trace de leurs propres actions)
create policy "audit_select_admin" on audit_logs for select
  using ( current_role_name() = 'ADMINA' );
create policy "audit_insert_all" on audit_logs for insert
  with check ( auth.uid() is not null );

-- ============================================================
-- DONNEES INITIALES (exemple)
-- ============================================================
insert into departements (nom) values
  ('ACHAT TECHNIQUE'),('SUPPLY CHAIN'),('COLLECTE'),('LOGISTIQUE MPF'),
  ('PRODUCTION'),('QUALITÉ HYGIÈNE'),('TECHNIQUE'),('R&D'),('CDG'),
  ('LOGISTIQUE MPE'),('RH'),('SSE'),('FINANCES'),('ACHAT'),('SSI'),
  ('BOOST'),('CODIR'),('MKT')
on conflict (nom) do nothing;

-- NB : les comptes utilisateurs (auth.users + profiles) se créent
-- depuis l'écran Admin de l'application (Supabase Auth Admin API),
-- pas par INSERT SQL direct, car le mot de passe doit passer par
-- Supabase Auth (hash sécurisé géré par Supabase).
