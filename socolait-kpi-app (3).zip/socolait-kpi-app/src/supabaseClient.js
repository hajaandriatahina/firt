import { createClient } from '@supabase/supabase-js'

const url = import.meta.env.VITE_SUPABASE_URL
const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY

export const supabase = createClient(url, anonKey)

// Les utilisateurs se connectent avec un "username" simple.
// Supabase Auth exige un email : on le fabrique en interne.
export const usernameToEmail = (username) =>
  `${username.trim().toLowerCase()}@socolait.local`
