import { useEffect, useMemo, useState } from 'react'
import { supabase } from '../../supabaseClient'
import { useAuth } from '../../context/AuthContext'
import {
  calculerStatut, objectifApplicable, MOIS_NOMS, joursDansLeMois, SEMAINES,
} from '../../utils/kpiCalc'

const ANNEES = [2025, 2026]
const FREQUENCES = [
  { value: 'MENSUELLE', label: 'Mensuel' },
  { value: 'HEBDOMADAIRE', label: 'Hebdomadaire' },
  { value: 'JOURNALIERE', label: 'Journalier' },
]

export default function SaisieKpi() {
  const { profile } = useAuth()
  const [kpis, setKpis] = useState([])
  const [objectifs, setObjectifs] = useState([])
  const [saisies, setSaisies] = useState([])
  const [annee, setAnnee] = useState(new Date().getFullYear())
  const [frequence, setFrequence] = useState('MENSUELLE')
  const [moisSelectionne, setMoisSelectionne] = useState(new Date().getMonth() + 1)
  const [planActionFor, setPlanActionFor] = useState(null) // { kpiId, saisieId }
  const [plan, setPlan] = useState({ probleme: '', cause: '', action: '', date_echeance: '' })
  const [saving, setSaving] = useState(null) // clé de la cellule en cours d'enregistrement

  useEffect(() => {
    if (profile) load()
  }, [profile, annee])

  const load = async () => {
    const { data: affectations } = await supabase
      .from('affectations_kpi')
      .select('kpi_id, kpis(*, departements(nom))')
      .eq('utilisateur_id', profile.id)
      .eq('actif', true)

    const kpiList = (affectations || []).map((a) => a.kpis)
    setKpis(kpiList)

    const kpiIds = kpiList.map((k) => k.id)

    const { data: obj } = await supabase
      .from('objectifs')
      .select('*')
      .in('kpi_id', kpiIds.length ? kpiIds : [0])
      .eq('annee', annee)
    setObjectifs(obj || [])

    const { data: s } = await supabase
      .from('saisies_kpi')
      .select('*')
      .eq('utilisateur_id', profile.id)
      .eq('annee', annee)
      .in('kpi_id', kpiIds.length ? kpiIds : [0])
    setSaisies(s || [])
  }

  // Colonnes affichées selon la fréquence choisie
  const colonnes = useMemo(() => {
    if (frequence === 'MENSUELLE') {
      return Array.from({ length: 12 }, (_, i) => ({ key: i + 1, label: MOIS_NOMS[i + 1] }))
    }
    if (frequence === 'HEBDOMADAIRE') {
      return SEMAINES.map((s) => ({ key: s, label: `S${s}` }))
    }
    // JOURNALIERE : jours du mois sélectionné
    const nbJours = joursDansLeMois(annee, moisSelectionne)
    return Array.from({ length: nbJours }, (_, i) => ({ key: i + 1, label: String(i + 1) }))
  }, [frequence, annee, moisSelectionne])

  // Retrouve la saisie existante pour un kpi + une colonne de période
  const trouverSaisie = (kpiId, colKey) => {
    return saisies.find((s) => {
      if (s.kpi_id !== kpiId) return false
      if (frequence === 'MENSUELLE') return s.mois === colKey && !s.semaine
      if (frequence === 'HEBDOMADAIRE') return s.semaine === colKey
      // journalier : on compare jour + mois via date_saisie
      if (!s.date_saisie) return false
      const d = new Date(s.date_saisie)
      return d.getMonth() + 1 === moisSelectionne && d.getDate() === colKey && s.mois === moisSelectionne
    })
  }

  const handleCellChange = async (kpi, colKey, valeurStr) => {
    const cellKey = `${kpi.id}-${colKey}`
    if (valeurStr === '') return
    const valeur = Number(valeurStr)
    if (Number.isNaN(valeur)) return

    setSaving(cellKey)
    const objectif = objectifApplicable(objectifs, kpi.id, annee)
    const statut = calculerStatut(valeur, objectif)
    const existante = trouverSaisie(kpi.id, colKey)

    const payload = { valeur, statut, annee }
    if (frequence === 'MENSUELLE') {
      payload.mois = colKey
      payload.periode = `${annee}-${String(colKey).padStart(2, '0')}`
      payload.date_saisie = `${annee}-${String(colKey).padStart(2, '0')}-01`
    } else if (frequence === 'HEBDOMADAIRE') {
      payload.semaine = colKey
      payload.periode = `${annee}-S${colKey}`
      payload.date_saisie = new Date().toISOString().slice(0, 10)
    } else {
      payload.mois = moisSelectionne
      payload.periode = `${annee}-${String(moisSelectionne).padStart(2, '0')}-${String(colKey).padStart(2, '0')}`
      payload.date_saisie = `${annee}-${String(moisSelectionne).padStart(2, '0')}-${String(colKey).padStart(2, '0')}`
    }

    let result
    if (existante) {
      result = await supabase
        .from('saisies_kpi')
        .update(payload)
        .eq('id', existante.id)
        .select()
        .single()
    } else {
      result = await supabase
        .from('saisies_kpi')
        .insert({ ...payload, kpi_id: kpi.id, utilisateur_id: profile.id })
        .select()
        .single()
    }

    setSaving(null)

    if (!result.error) {
      setSaisies((prev) => {
        const autres = prev.filter((s) => s.id !== result.data.id)
        return [...autres, result.data]
      })
      if (statut === 'NON_CONFORME') {
        setPlanActionFor({ kpiId: kpi.id, saisieId: result.data.id })
      }
    }
  }

  const handlePlanSubmit = async (e) => {
    e.preventDefault()
    await supabase.from('plans_actions').insert({
      kpi_id: planActionFor.kpiId,
      saisie_kpi_id: planActionFor.saisieId,
      responsable_id: profile.id,
      ...plan,
      statut: 'EN_COURS',
    })
    setPlanActionFor(null)
    setPlan({ probleme: '', cause: '', action: '', date_echeance: '' })
  }

  return (
    <div>
      <h1>Saisie KPI</h1>

      <div className="filters-row">
        <label>
          Année
          <select value={annee} onChange={(e) => setAnnee(Number(e.target.value))}>
            {ANNEES.map((a) => <option key={a} value={a}>{a}</option>)}
          </select>
        </label>
        <label>
          Fréquence
          <select value={frequence} onChange={(e) => setFrequence(e.target.value)}>
            {FREQUENCES.map((f) => <option key={f.value} value={f.value}>{f.label}</option>)}
          </select>
        </label>
        {frequence === 'JOURNALIERE' && (
          <label>
            Mois
            <select value={moisSelectionne} onChange={(e) => setMoisSelectionne(Number(e.target.value))}>
              {MOIS_NOMS.slice(1).map((nom, i) => (
                <option key={i + 1} value={i + 1}>{nom}</option>
              ))}
            </select>
          </label>
        )}
      </div>

      <div className="table-scroll">
        <table className="data-table kpi-entry-table">
          <thead>
            <tr>
              <th className="sticky-col">Département</th>
              <th className="sticky-col2">KPI</th>
              <th>Unité</th>
              <th>Objectif</th>
              {colonnes.map((c) => <th key={c.key}>{c.label}</th>)}
            </tr>
          </thead>
          <tbody>
            {kpis.map((kpi) => {
              const objectif = objectifApplicable(objectifs, kpi.id, annee)
              return (
                <tr key={kpi.id}>
                  <td className="sticky-col">{kpi.departements?.nom ?? '—'}</td>
                  <td className="sticky-col2">{kpi.nom}</td>
                  <td>{kpi.unite}</td>
                  <td className="objectif-cell">
                    {objectif ? `${objectif.operateur} ${objectif.valeur_objectif}` : '—'}
                  </td>
                  {colonnes.map((c) => {
                    const existante = trouverSaisie(kpi.id, c.key)
                    const cellKey = `${kpi.id}-${c.key}`
                    return (
                      <td key={c.key} className={
                        existante?.statut === 'CONFORME' ? 'cell-conforme'
                          : existante?.statut === 'NON_CONFORME' ? 'cell-non-conforme' : ''
                      }>
                        <input
                          type="number"
                          step="0.01"
                          className="cell-input"
                          defaultValue={existante ? existante.valeur : ''}
                          disabled={saving === cellKey}
                          onBlur={(e) => handleCellChange(kpi, c.key, e.target.value)}
                        />
                      </td>
                    )
                  })}
                </tr>
              )
            })}
            {kpis.length === 0 && (
              <tr><td colSpan={4 + colonnes.length}>Aucun KPI ne vous est affecté.</td></tr>
            )}
          </tbody>
        </table>
      </div>

      <p className="table-hint">Saisissez une valeur puis cliquez ailleurs pour l'enregistrer automatiquement.</p>

      {planActionFor && (
        <form className="form-card alert-card" onSubmit={handlePlanSubmit}>
          <h3>⚠️ Plan d'action requis (KPI non conforme)</h3>
          <label>
            Problème
            <input value={plan.probleme} onChange={(e) => setPlan({ ...plan, probleme: e.target.value })} required />
          </label>
          <label>
            Cause
            <input value={plan.cause} onChange={(e) => setPlan({ ...plan, cause: e.target.value })} required />
          </label>
          <label>
            Action corrective
            <input value={plan.action} onChange={(e) => setPlan({ ...plan, action: e.target.value })} required />
          </label>
          <label>
            Échéance
            <input type="date" value={plan.date_echeance} onChange={(e) => setPlan({ ...plan, date_echeance: e.target.value })} required />
          </label>
          <div style={{ display: 'flex', gap: 10 }}>
            <button className="btn-primary" type="submit">Enregistrer le plan d'action</button>
            <button className="btn-secondary" type="button" onClick={() => setPlanActionFor(null)}>Plus tard</button>
          </div>
        </form>
      )}
    </div>
  )
}
