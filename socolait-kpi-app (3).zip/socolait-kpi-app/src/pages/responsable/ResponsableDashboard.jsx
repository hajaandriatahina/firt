import { useEffect, useState } from 'react'
import { supabase } from '../../supabaseClient'
import { useAuth } from '../../context/AuthContext'
import { calculerStatut, objectifApplicable } from '../../utils/kpiCalc'

export default function ResponsableDashboard() {
  const { profile } = useAuth()
  const [rows, setRows] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (profile) load()
  }, [profile])

  const load = async () => {
    setLoading(true)
    const annee = new Date().getFullYear()

    const { data: affectations } = await supabase
      .from('affectations_kpi')
      .select('kpi_id, kpis(*)')
      .eq('utilisateur_id', profile.id)
      .eq('actif', true)

    const kpiIds = (affectations || []).map((a) => a.kpi_id)

    const { data: objectifs } = await supabase
      .from('objectifs')
      .select('*')
      .in('kpi_id', kpiIds.length ? kpiIds : [0])
      .eq('annee', annee)

    const { data: saisies } = await supabase
      .from('saisies_kpi')
      .select('*')
      .eq('utilisateur_id', profile.id)
      .order('date_saisie', { ascending: false })

    const result = (affectations || []).map((a) => {
      const objectif = objectifApplicable(objectifs || [], a.kpi_id, annee)
      const derniereSaisie = (saisies || []).find((s) => s.kpi_id === a.kpi_id)
      return {
        kpi: a.kpis,
        objectif,
        derniereSaisie,
        statut: derniereSaisie ? calculerStatut(derniereSaisie.valeur, objectif) : null,
      }
    })

    setRows(result)
    setLoading(false)
  }

  if (loading) return <p>Chargement...</p>

  const totalConforme = rows.filter((r) => r.statut === 'CONFORME').length
  const totalNonConforme = rows.filter((r) => r.statut === 'NON_CONFORME').length

  return (
    <div>
      <h1>Mes KPI</h1>

      <div className="cards-row">
        <div className="stat-card">
          <span>Total KPI</span>
          <strong>{rows.length}</strong>
        </div>
        <div className="stat-card conforme">
          <span>Conformes</span>
          <strong>{totalConforme}</strong>
        </div>
        <div className="stat-card non-conforme">
          <span>Non conformes</span>
          <strong>{totalNonConforme}</strong>
        </div>
      </div>

      <table className="data-table">
        <thead>
          <tr>
            <th>KPI</th>
            <th>Objectif</th>
            <th>Dernière valeur</th>
            <th>Statut</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.kpi.id}>
              <td>{r.kpi.nom}</td>
              <td>
                {r.objectif
                  ? `${r.objectif.operateur} ${r.objectif.valeur_objectif} ${r.kpi.unite || ''}`
                  : '—'}
              </td>
              <td>{r.derniereSaisie ? `${r.derniereSaisie.valeur} ${r.kpi.unite || ''}` : '—'}</td>
              <td>
                {r.statut === 'CONFORME' && <span className="badge badge-green">🟢 Conforme</span>}
                {r.statut === 'NON_CONFORME' && <span className="badge badge-red">🔴 Non conforme</span>}
                {!r.statut && <span className="badge">—</span>}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
