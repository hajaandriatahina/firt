import { useEffect, useState } from 'react'
import { supabase } from '../../supabaseClient'

const OPERATEURS = ['>=', '<=', '>', '<', '=']

export default function Objectifs() {
  const [list, setList] = useState([])
  const [kpis, setKpis] = useState([])
  const [form, setForm] = useState({
    kpi_id: '', valeur_objectif: '', operateur: '>=', annee: new Date().getFullYear(),
    date_debut: '', date_fin: '',
  })

  useEffect(() => { load() }, [])

  const load = async () => {
    const { data: o } = await supabase.from('objectifs').select('*, kpis(nom, unite)').order('annee', { ascending: false })
    const { data: k } = await supabase.from('kpis').select('*').order('nom')
    setList(o || [])
    setKpis(k || [])
  }

  const handleAdd = async (e) => {
    e.preventDefault()
    await supabase.from('objectifs').insert({
      ...form,
      kpi_id: Number(form.kpi_id),
      valeur_objectif: Number(form.valeur_objectif),
      annee: Number(form.annee),
    })
    setForm({ kpi_id: '', valeur_objectif: '', operateur: '>=', annee: new Date().getFullYear(), date_debut: '', date_fin: '' })
    load()
  }

  const remove = async (id) => {
    await supabase.from('objectifs').delete().eq('id', id)
    load()
  }

  return (
    <div>
      <h1>Objectifs</h1>
      <form className="form-card" onSubmit={handleAdd}>
        <div className="form-grid">
          <label>KPI
            <select value={form.kpi_id} onChange={(e) => setForm({ ...form, kpi_id: e.target.value })} required>
              <option value="">--</option>
              {kpis.map((k) => <option key={k.id} value={k.id}>{k.nom}</option>)}
            </select>
          </label>
          <label>Opérateur
            <select value={form.operateur} onChange={(e) => setForm({ ...form, operateur: e.target.value })}>
              {OPERATEURS.map((o) => <option key={o} value={o}>{o}</option>)}
            </select>
          </label>
          <label>Valeur objectif
            <input type="number" step="0.01" value={form.valeur_objectif} onChange={(e) => setForm({ ...form, valeur_objectif: e.target.value })} required />
          </label>
          <label>Année
            <input type="number" value={form.annee} onChange={(e) => setForm({ ...form, annee: e.target.value })} required />
          </label>
          <label>Date début
            <input type="date" value={form.date_debut} onChange={(e) => setForm({ ...form, date_debut: e.target.value })} />
          </label>
          <label>Date fin
            <input type="date" value={form.date_fin} onChange={(e) => setForm({ ...form, date_fin: e.target.value })} />
          </label>
        </div>
        <button className="btn-primary" type="submit">Ajouter l'objectif</button>
      </form>

      <table className="data-table">
        <thead><tr><th>KPI</th><th>Objectif</th><th>Année</th><th></th></tr></thead>
        <tbody>
          {list.map((o) => (
            <tr key={o.id}>
              <td>{o.kpis?.nom}</td>
              <td>{o.operateur} {o.valeur_objectif} {o.kpis?.unite}</td>
              <td>{o.annee}</td>
              <td><button className="btn-danger" onClick={() => remove(o.id)}>Supprimer</button></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
