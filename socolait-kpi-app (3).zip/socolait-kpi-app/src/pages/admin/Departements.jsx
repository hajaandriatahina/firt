import { useEffect, useState } from 'react'
import { supabase } from '../../supabaseClient'

export default function Departements() {
  const [list, setList] = useState([])
  const [nom, setNom] = useState('')
  const [description, setDescription] = useState('')

  useEffect(() => { load() }, [])

  const load = async () => {
    const { data } = await supabase.from('departements').select('*').order('nom')
    setList(data || [])
  }

  const handleAdd = async (e) => {
    e.preventDefault()
    await supabase.from('departements').insert({ nom, description })
    setNom(''); setDescription('')
    load()
  }

  const remove = async (id) => {
    await supabase.from('departements').delete().eq('id', id)
    load()
  }

  return (
    <div>
      <h1>Départements</h1>
      <form className="form-card inline-form" onSubmit={handleAdd}>
        <input placeholder="Nom du département" value={nom} onChange={(e) => setNom(e.target.value)} required />
        <input placeholder="Description" value={description} onChange={(e) => setDescription(e.target.value)} />
        <button className="btn-primary" type="submit">Ajouter</button>
      </form>
      <table className="data-table">
        <thead><tr><th>Nom</th><th>Description</th><th>Actif</th><th></th></tr></thead>
        <tbody>
          {list.map((d) => (
            <tr key={d.id}>
              <td>{d.nom}</td>
              <td>{d.description}</td>
              <td>{d.actif ? 'Oui' : 'Non'}</td>
              <td><button className="btn-danger" onClick={() => remove(d.id)}>Supprimer</button></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
