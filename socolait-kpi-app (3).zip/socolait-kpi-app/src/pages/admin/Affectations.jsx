import { useEffect, useState } from 'react'
import { supabase } from '../../supabaseClient'

export default function Affectations() {
  const [list, setList] = useState([])
  const [responsables, setResponsables] = useState([])
  const [kpis, setKpis] = useState([])
  const [form, setForm] = useState({ utilisateur_id: '', kpi_id: '' })
  const [message, setMessage] = useState('')

  useEffect(() => { load() }, [])

  const load = async () => {
    const { data: a } = await supabase
      .from('affectations_kpi')
      .select('*, profiles(username, nom, prenom), kpis(nom)')
      .eq('actif', true)
    const { data: r } = await supabase.from('profiles').select('*').eq('role', 'RESPONSABLE')
    const { data: k } = await supabase.from('kpis').select('*').order('nom')
    setList(a || [])
    setResponsables(r || [])
    setKpis(k || [])
  }

  const handleAdd = async (e) => {
    e.preventDefault()
    setMessage('')
    const { error } = await supabase.from('affectations_kpi').insert({
      utilisateur_id: form.utilisateur_id,
      kpi_id: Number(form.kpi_id),
    })
    if (error) {
      setMessage('Erreur : ' + error.message)
      return
    }
    setForm({ utilisateur_id: '', kpi_id: '' })
    load()
  }

  const remove = async (id) => {
    await supabase.from('affectations_kpi').update({ actif: false }).eq('id', id)
    load()
  }

  return (
    <div>
      <h1>Affectation des KPI</h1>
      <form className="form-card inline-form" onSubmit={handleAdd}>
        <select value={form.utilisateur_id} onChange={(e) => setForm({ ...form, utilisateur_id: e.target.value })} required>
          <option value="">-- Responsable --</option>
          {responsables.map((r) => <option key={r.id} value={r.id}>{r.prenom} {r.nom} ({r.username})</option>)}
        </select>
        <select value={form.kpi_id} onChange={(e) => setForm({ ...form, kpi_id: e.target.value })} required>
          <option value="">-- KPI --</option>
          {kpis.map((k) => <option key={k.id} value={k.id}>{k.nom}</option>)}
        </select>
        <button className="btn-primary" type="submit">Affecter</button>
      </form>
      {message && <p className="form-message">{message}</p>}

      <table className="data-table">
        <thead><tr><th>Responsable</th><th>KPI</th><th></th></tr></thead>
        <tbody>
          {list.map((a) => (
            <tr key={a.id}>
              <td>{a.profiles?.prenom} {a.profiles?.nom} ({a.profiles?.username})</td>
              <td>{a.kpis?.nom}</td>
              <td><button className="btn-danger" onClick={() => remove(a.id)}>Retirer</button></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
