import { useEffect, useState } from 'react'
import { supabase } from '../../supabaseClient'

const FREQUENCES = ['JOURNALIERE', 'HEBDOMADAIRE', 'MENSUELLE']

export default function Kpis() {
  const [list, setList] = useState([])
  const [departements, setDepartements] = useState([])
  const [form, setForm] = useState({
    code: '', nom: '', description: '', departement_id: '', unite: '', frequence: 'MENSUELLE',
  })

  useEffect(() => { load() }, [])

  const load = async () => {
    const { data: k } = await supabase.from('kpis').select('*, departements(nom)').order('nom')
    const { data: d } = await supabase.from('departements').select('*').order('nom')
    setList(k || [])
    setDepartements(d || [])
  }

  const handleAdd = async (e) => {
    e.preventDefault()
    await supabase.from('kpis').insert({
      ...form,
      departement_id: form.departement_id ? Number(form.departement_id) : null,
    })
    setForm({ code: '', nom: '', description: '', departement_id: '', unite: '', frequence: 'MENSUELLE' })
    load()
  }

  const remove = async (id) => {
    await supabase.from('kpis').delete().eq('id', id)
    load()
  }

  return (
    <div>
      <h1>KPI</h1>
      <form className="form-card" onSubmit={handleAdd}>
        <div className="form-grid">
          <label>Code<input value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} /></label>
          <label>Nom<input value={form.nom} onChange={(e) => setForm({ ...form, nom: e.target.value })} required /></label>
          <label>Département
            <select value={form.departement_id} onChange={(e) => setForm({ ...form, departement_id: e.target.value })}>
              <option value="">--</option>
              {departements.map((d) => <option key={d.id} value={d.id}>{d.nom}</option>)}
            </select>
          </label>
          <label>Unité<input value={form.unite} onChange={(e) => setForm({ ...form, unite: e.target.value })} placeholder="%, kg, tonne..." /></label>
          <label>Fréquence
            <select value={form.frequence} onChange={(e) => setForm({ ...form, frequence: e.target.value })}>
              {FREQUENCES.map((f) => <option key={f} value={f}>{f}</option>)}
            </select>
          </label>
        </div>
        <label>Description<textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></label>
        <button className="btn-primary" type="submit">Ajouter le KPI</button>
      </form>

      <table className="data-table">
        <thead><tr><th>Code</th><th>Nom</th><th>Département</th><th>Unité</th><th>Fréquence</th><th></th></tr></thead>
        <tbody>
          {list.map((k) => (
            <tr key={k.id}>
              <td>{k.code}</td>
              <td>{k.nom}</td>
              <td>{k.departements?.nom || '—'}</td>
              <td>{k.unite}</td>
              <td>{k.frequence}</td>
              <td><button className="btn-danger" onClick={() => remove(k.id)}>Supprimer</button></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
