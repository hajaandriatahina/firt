import { useEffect, useState } from 'react'
import { supabase } from '../../supabaseClient'

export default function AdminDashboard() {
  const [counts, setCounts] = useState({ users: 0, kpis: 0, dept: 0, nonConforme: 0 })

  useEffect(() => {
    load()
  }, [])

  const load = async () => {
    const [{ count: users }, { count: kpis }, { count: dept }, { count: nonConforme }] =
      await Promise.all([
        supabase.from('profiles').select('*', { count: 'exact', head: true }),
        supabase.from('kpis').select('*', { count: 'exact', head: true }),
        supabase.from('departements').select('*', { count: 'exact', head: true }),
        supabase
          .from('saisies_kpi')
          .select('*', { count: 'exact', head: true })
          .eq('statut', 'NON_CONFORME'),
      ])
    setCounts({ users: users || 0, kpis: kpis || 0, dept: dept || 0, nonConforme: nonConforme || 0 })
  }

  return (
    <div>
      <h1>Administration</h1>
      <div className="cards-row">
        <div className="stat-card"><span>Utilisateurs</span><strong>{counts.users}</strong></div>
        <div className="stat-card"><span>KPI</span><strong>{counts.kpis}</strong></div>
        <div className="stat-card"><span>Départements</span><strong>{counts.dept}</strong></div>
        <div className="stat-card non-conforme"><span>Saisies non conformes</span><strong>{counts.nonConforme}</strong></div>
      </div>
      <p>Utilisez le menu à gauche pour gérer les utilisateurs, départements, KPI, objectifs et affectations.</p>
    </div>
  )
}
