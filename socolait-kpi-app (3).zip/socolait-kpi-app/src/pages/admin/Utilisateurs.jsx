import { useEffect, useState } from 'react'
import { supabase } from '../../supabaseClient'

const ROLES = ['ADMINA', 'DIRECTEUR', 'RESPONSABLE']

export default function Utilisateurs() {
  const [users, setUsers] = useState([])
  const [departements, setDepartements] = useState([])
  const [form, setForm] = useState({
    username: '', password: '', nom: '', prenom: '', role: 'RESPONSABLE', departement_id: '',
  })
  const [message, setMessage] = useState('')

  useEffect(() => { load() }, [])

  const load = async () => {
    const { data: u } = await supabase.from('profiles').select('*, departements(nom)').order('created_at')
    const { data: d } = await supabase.from('departements').select('*').order('nom')
    setUsers(u || [])
    setDepartements(d || [])
  }

  const handleCreate = async (e) => {
    e.preventDefault()
    setMessage('')
    // Appelle l'Edge Function Supabase "create-user" (voir supabase/functions)
    const { data, error } = await supabase.functions.invoke('create-user', {
      body: { ...form, departement_id: form.departement_id ? Number(form.departement_id) : null },
    })
    if (error || data?.ok === false) {
      setMessage('Erreur : ' + (data?.error || error.message))
      return
    }
    setMessage('Utilisateur créé.')
    setForm({ username: '', password: '', nom: '', prenom: '', role: 'RESPONSABLE', departement_id: '' })
    load()
  }

  const toggleStatut = async (u) => {
    const nouveauStatut = u.statut === 'ACTIF' ? 'INACTIF' : 'ACTIF'
    await supabase.from('profiles').update({ statut: nouveauStatut }).eq('id', u.id)
    load()
  }

  return (
    <div>
      <h1>Utilisateurs</h1>

      <form className="form-card" onSubmit={handleCreate}>
        <h3>Nouvel utilisateur</h3>
        <div className="form-grid">
          <label>Nom d'utilisateur
            <input value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} required />
          </label>
          <label>Mot de passe
            <input type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} required />
          </label>
          <label>Nom
            <input value={form.nom} onChange={(e) => setForm({ ...form, nom: e.target.value })} />
          </label>
          <label>Prénom
            <input value={form.prenom} onChange={(e) => setForm({ ...form, prenom: e.target.value })} />
          </label>
          <label>Rôle
            <select value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })}>
              {ROLES.map((r) => <option key={r} value={r}>{r}</option>)}
            </select>
          </label>
          <label>Département
            <select value={form.departement_id} onChange={(e) => setForm({ ...form, departement_id: e.target.value })}>
              <option value="">--</option>
              {departements.map((d) => <option key={d.id} value={d.id}>{d.nom}</option>)}
            </select>
          </label>
        </div>
        <button className="btn-primary" type="submit">Créer</button>
        {message && <p className="form-message">{message}</p>}
      </form>

      <table className="data-table">
        <thead>
          <tr><th>Username</th><th>Nom</th><th>Rôle</th><th>Département</th><th>Statut</th><th></th></tr>
        </thead>
        <tbody>
          {users.map((u) => (
            <tr key={u.id}>
              <td>{u.username}</td>
              <td>{u.prenom} {u.nom}</td>
              <td>{u.role}</td>
              <td>{u.departements?.nom || '—'}</td>
              <td>{u.statut}</td>
              <td><button className="btn-secondary" onClick={() => toggleStatut(u)}>
                {u.statut === 'ACTIF' ? 'Désactiver' : 'Activer'}
              </button></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
