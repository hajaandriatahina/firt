import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase, usernameToEmail } from '../supabaseClient'

export default function Login() {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const navigate = useNavigate()

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    setLoading(true)
    const { error } = await supabase.auth.signInWithPassword({
      email: usernameToEmail(username),
      password,
    })
    setLoading(false)
    if (error) {
      setError("Nom d'utilisateur ou mot de passe incorrect.")
      return
    }
    navigate('/')
  }

  return (
    <div className="login-screen">
      <div className="login-panel-left">
        <div className="login-brand">
          <h1>Socolait</h1>
          <p>Suivi et automatisation des indicateurs KPI</p>
        </div>
      </div>
      <div className="login-panel-right">
        <form className="login-form" onSubmit={handleSubmit}>
          <h2>Connexion</h2>
          <label>
            Nom d'utilisateur
            <input
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="ex: rina"
              required
            />
          </label>
          <label>
            Mot de passe
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </label>
          {error && <div className="form-error">{error}</div>}
          <button className="btn-primary" type="submit" disabled={loading}>
            {loading ? 'Connexion...' : 'Se connecter'}
          </button>
        </form>
      </div>
    </div>
  )
}
