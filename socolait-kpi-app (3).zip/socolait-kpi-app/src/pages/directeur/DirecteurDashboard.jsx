import { useEffect, useMemo, useState } from 'react'
import {
  ComposedChart, Bar, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend,
} from 'recharts'
import { supabase } from '../../supabaseClient'
import { MOIS_NOMS } from '../../utils/kpiCalc'

const ANNEES = [2025, 2026]
const FREQUENCES = [
  { value: '', label: 'Toutes' },
  { value: 'JOURNALIERE', label: 'Journalier' },
  { value: 'HEBDOMADAIRE', label: 'Hebdomadaire' },
  { value: 'MENSUELLE', label: 'Mensuel' },
]

export default function DirecteurDashboard() {
  const [saisies, setSaisies] = useState([])
  const [departements, setDepartements] = useState([])
  const [filtreDept, setFiltreDept] = useState('')
  const [filtreFrequence, setFiltreFrequence] = useState('')
  const [annee, setAnnee] = useState(new Date().getFullYear())
  const [loading, setLoading] = useState(true)

  useEffect(() => { load() }, [annee])

  const load = async () => {
    setLoading(true)
    const { data: s } = await supabase
      .from('saisies_kpi')
      .select('*, kpis(nom, departement_id, frequence, departements:departement_id(nom))')
      .eq('annee', annee)
      .order('mois', { ascending: true })
    const { data: d } = await supabase.from('departements').select('*').order('nom')
    setSaisies(s || [])
    setDepartements(d || [])
    setLoading(false)
  }

  const filtered = useMemo(() => {
    return saisies.filter((s) => {
      if (filtreDept && String(s.kpis?.departement_id) !== String(filtreDept)) return false
      if (filtreFrequence && s.kpis?.frequence !== filtreFrequence) return false
      return true
    })
  }, [saisies, filtreDept, filtreFrequence])

  // Un seul graphique agrégé, toujours par mois (comme le suivi Excel)
  const parMois = useMemo(() => {
    const map = {}
    for (let m = 1; m <= 12; m++) {
      map[m] = { mois: MOIS_NOMS[m], conforme: 0, nonConforme: 0, sommeTaux: 0, nbTaux: 0 }
    }
    filtered.forEach((s) => {
      if (!s.mois) return
      const bucket = map[s.mois]
      if (!bucket) return
      if (s.statut === 'CONFORME') bucket.conforme += 1
      else if (s.statut === 'NON_CONFORME') bucket.nonConforme += 1
    })
    return Object.values(map).map((b) => {
      const total = b.conforme + b.nonConforme
      return {
        mois: b.mois,
        conforme: b.conforme,
        nonConforme: b.nonConforme,
        tauxRealisation: total ? Math.round((b.conforme / total) * 100) : null,
        objectif: 100,
      }
    })
  }, [filtered])

  const totalConforme = filtered.filter((s) => s.statut === 'CONFORME').length
  const totalNonConforme = filtered.filter((s) => s.statut === 'NON_CONFORME').length
  const tauxConformite = filtered.length
    ? Math.round((totalConforme / filtered.length) * 100)
    : 0

  if (loading) return <p>Chargement...</p>

  return (
    <div>
      <h1>Dashboard Directeur</h1>

      <div className="filters-row">
        <label>
          Année
          <select value={annee} onChange={(e) => setAnnee(Number(e.target.value))}>
            {ANNEES.map((a) => <option key={a} value={a}>{a}</option>)}
          </select>
        </label>
        <label>
          Fréquence
          <select value={filtreFrequence} onChange={(e) => setFiltreFrequence(e.target.value)}>
            {FREQUENCES.map((f) => <option key={f.value} value={f.value}>{f.label}</option>)}
          </select>
        </label>
        <label>
          Département
          <select value={filtreDept} onChange={(e) => setFiltreDept(e.target.value)}>
            <option value="">Tous</option>
            {departements.map((d) => <option key={d.id} value={d.id}>{d.nom}</option>)}
          </select>
        </label>
      </div>

      <div className="cards-row">
        <div className="stat-card"><span>Saisies analysées</span><strong>{filtered.length}</strong></div>
        <div className="stat-card conforme"><span>Conformes</span><strong>{totalConforme}</strong></div>
        <div className="stat-card non-conforme"><span>Non conformes</span><strong>{totalNonConforme}</strong></div>
        <div className="stat-card"><span>Taux de conformité</span><strong>{tauxConformite}%</strong></div>
      </div>

      <div className="chart-card">
        <h3>Conformité par mois — {annee}</h3>
        <ResponsiveContainer width="100%" height={340}>
          <ComposedChart data={parMois}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="mois" tick={{ fontSize: 11 }} />
            <YAxis unit="%" domain={[0, 100]} />
            <Tooltip />
            <Legend />
            <Bar dataKey="conforme" name="Saisies conformes (cumul)" fill="#374151" barSize={26} />
            <Line type="monotone" dataKey="tauxRealisation" name="Taux réalisé (%)" stroke="#2563eb" strokeWidth={2} connectNulls />
            <Line type="monotone" dataKey="objectif" name="Objectif (%)" stroke="#16a34a" strokeWidth={2} dot={false} />
          </ComposedChart>
        </ResponsiveContainer>
      </div>

      <table className="data-table">
        <thead>
          <tr><th>Date</th><th>KPI</th><th>Département</th><th>Fréquence</th><th>Valeur</th><th>Statut</th></tr>
        </thead>
        <tbody>
          {filtered.slice(0, 30).map((s) => (
            <tr key={s.id}>
              <td>{s.date_saisie}</td>
              <td>{s.kpis?.nom}</td>
              <td>{s.kpis?.departements?.nom}</td>
              <td>{s.kpis?.frequence}</td>
              <td>{s.valeur}</td>
              <td>
                {s.statut === 'CONFORME' && <span className="badge badge-green">🟢</span>}
                {s.statut === 'NON_CONFORME' && <span className="badge badge-red">🔴</span>}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
