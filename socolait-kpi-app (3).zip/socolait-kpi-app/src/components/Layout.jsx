import { NavLink } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

const MENUS = {
  ADMINA: [
    { to: '/admin', label: 'Dashboard' },
    { to: '/admin/utilisateurs', label: 'Utilisateurs' },
    { to: '/admin/departements', label: 'Départements' },
    { to: '/admin/kpis', label: 'KPI' },
    { to: '/admin/objectifs', label: 'Objectifs' },
    { to: '/admin/affectations', label: 'Affectations' },
  ],
  RESPONSABLE: [
    { to: '/responsable', label: 'Mes KPI' },
    { to: '/responsable/saisie', label: 'Saisie' },
  ],
  DIRECTEUR: [{ to: '/directeur', label: 'Dashboard global' }],
}

export default function Layout({ children }) {
  const { profile, signOut } = useAuth()
  const menu = MENUS[profile?.role] || []

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">Socolait KPI</div>
        <nav>
          {menu.map((item) => (
            <NavLink key={item.to} to={item.to} end className="nav-link">
              {item.label}
            </NavLink>
          ))}
        </nav>
      </aside>
      <div className="main-col">
        <header className="navbar">
          <div>
            <strong>{profile?.prenom} {profile?.nom}</strong>
            <span className="role-badge">{profile?.role}</span>
          </div>
          <button className="btn-secondary" onClick={signOut}>Déconnexion</button>
        </header>
        <main className="content">{children}</main>
      </div>
    </div>
  )
}
