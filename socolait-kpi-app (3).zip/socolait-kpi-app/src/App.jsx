import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider, useAuth } from './context/AuthContext'
import ProtectedRoute from './components/ProtectedRoute'
import Layout from './components/Layout'

import Login from './pages/Login'
import AdminDashboard from './pages/admin/AdminDashboard'
import Utilisateurs from './pages/admin/Utilisateurs'
import Departements from './pages/admin/Departements'
import Kpis from './pages/admin/Kpis'
import Objectifs from './pages/admin/Objectifs'
import Affectations from './pages/admin/Affectations'
import ResponsableDashboard from './pages/responsable/ResponsableDashboard'
import SaisieKpi from './pages/responsable/SaisieKpi'
import DirecteurDashboard from './pages/directeur/DirecteurDashboard'

function HomeRedirect() {
  const { profile, loading } = useAuth()
  if (loading) return <div className="page-loading">Chargement...</div>
  if (!profile) return <Navigate to="/login" replace />
  if (profile.role === 'ADMINA') return <Navigate to="/admin" replace />
  if (profile.role === 'DIRECTEUR') return <Navigate to="/directeur" replace />
  return <Navigate to="/responsable" replace />
}

function withLayout(children, roles) {
  return (
    <ProtectedRoute allowedRoles={roles}>
      <Layout>{children}</Layout>
    </ProtectedRoute>
  )
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/" element={<HomeRedirect />} />

          {/* ADMIN */}
          <Route path="/admin" element={withLayout(<AdminDashboard />, ['ADMINA'])} />
          <Route path="/admin/utilisateurs" element={withLayout(<Utilisateurs />, ['ADMINA'])} />
          <Route path="/admin/departements" element={withLayout(<Departements />, ['ADMINA'])} />
          <Route path="/admin/kpis" element={withLayout(<Kpis />, ['ADMINA'])} />
          <Route path="/admin/objectifs" element={withLayout(<Objectifs />, ['ADMINA'])} />
          <Route path="/admin/affectations" element={withLayout(<Affectations />, ['ADMINA'])} />

          {/* RESPONSABLE */}
          <Route path="/responsable" element={withLayout(<ResponsableDashboard />, ['RESPONSABLE'])} />
          <Route path="/responsable/saisie" element={withLayout(<SaisieKpi />, ['RESPONSABLE'])} />

          {/* DIRECTEUR */}
          <Route path="/directeur" element={withLayout(<DirecteurDashboard />, ['DIRECTEUR'])} />

          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </AuthProvider>
    </BrowserRouter>
  )
}
