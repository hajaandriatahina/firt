// Compare une valeur réalisée à un objectif selon l'opérateur défini
export function calculerStatut(valeur, objectif) {
  if (!objectif) return null
  const { valeur_objectif, operateur } = objectif
  let conforme = false
  switch (operateur) {
    case '>=': conforme = valeur >= valeur_objectif; break
    case '<=': conforme = valeur <= valeur_objectif; break
    case '>':  conforme = valeur > valeur_objectif; break
    case '<':  conforme = valeur < valeur_objectif; break
    case '=':  conforme = valeur === valeur_objectif; break
    default:   conforme = valeur >= valeur_objectif
  }
  return conforme ? 'CONFORME' : 'NON_CONFORME'
}

// Retourne l'objectif applicable pour un KPI à une année donnée
export function objectifApplicable(objectifs, kpiId, annee) {
  return objectifs
    .filter((o) => o.kpi_id === kpiId && o.annee === annee)
    .sort((a, b) => new Date(b.date_debut || 0) - new Date(a.date_debut || 0))[0]
}

// Noms des mois (index 1 = Janvier ... 12 = Décembre)
export const MOIS_NOMS = [
  '', 'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin',
  'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre',
]

// Nombre de jours dans un mois donné (mois: 1-12)
export function joursDansLeMois(annee, mois) {
  return new Date(annee, mois, 0).getDate()
}

// Nombre de semaines ISO approximatif à afficher pour une année (1 à 52)
export const SEMAINES = Array.from({ length: 52 }, (_, i) => i + 1)

// Numéro de semaine ISO d'une date
export function numeroSemaineISO(date) {
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()))
  const dayNum = d.getUTCDay() || 7
  d.setUTCDate(d.getUTCDate() + 4 - dayNum)
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1))
  return Math.ceil((((d - yearStart) / 86400000) + 1) / 7)
}
