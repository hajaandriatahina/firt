# Socolait KPI — application React + Supabase (sans backend)

Application de digitalisation des KPI de Socolait. React se connecte
**directement** à Supabase (Auth + Postgres + Row Level Security) : il n'y a
pas de serveur backend à héberger séparément.

## 1. Créer le projet Supabase

1. Créez un projet sur https://supabase.com
2. Allez dans **SQL Editor** et exécutez tout le contenu de `supabase/schema.sql`
   (il crée les tables, active la Row Level Security et insère les départements).
3. Récupérez, dans **Project Settings > API** :
   - `Project URL` → `VITE_SUPABASE_URL`
   - `anon public key` → `VITE_SUPABASE_ANON_KEY`

## 2. Configurer l'application

```bash
cp .env.example .env
# puis remplir .env avec vos vraies clés Supabase
npm install
npm run dev
```

## 3. Déployer la fonction de création d'utilisateurs

Créer un utilisateur (avec mot de passe) doit passer par la clé `service_role`
de Supabase, qui ne doit **jamais** être présente dans le code React. C'est
pour cela qu'une petite Edge Function Supabase (`supabase/functions/create-user`)
s'en charge — elle tourne chez Supabase, ce n'est pas un serveur à gérer.

```bash
npm install -g supabase
supabase login
supabase link --project-ref VOTRE_PROJECT_REF
supabase functions deploy create-user
```

Une fois déployée, l'écran **Admin > Utilisateurs** peut créer des comptes.

## 4. Créer le premier compte ADMINA

Avant que l'écran "Utilisateurs" existe, créez le tout premier Admina à la main :

1. Dans Supabase, **Authentication > Users > Add user**, email
   `admin@socolait.local`, définissez un mot de passe.
2. Dans **Table editor > profiles**, ajoutez une ligne avec le même `id`
   (copié depuis l'utilisateur créé), `username = admin`, `role = ADMINA`.
3. Connectez-vous dans l'application avec `admin` / le mot de passe choisi.

Ensuite, tout le reste (départements, KPI, objectifs, affectations,
utilisateurs Responsable/Directeur) se gère depuis l'interface Admin.

## Fonctionnement des rôles

- **ADMINA** : configure tout (utilisateurs, départements, KPI, objectifs,
  affectations).
- **RESPONSABLE** : voit uniquement ses KPI affectés (`/responsable`), saisit
  ses valeurs (`/responsable/saisie`). Si un KPI est non conforme, un plan
  d'action est demandé automatiquement.
- **DIRECTEUR** : consulte le dashboard global, filtre par département, voit
  les graphiques de conformité (`/directeur`).

La Row Level Security de `schema.sql` applique ces règles **côté base de
données** (pas seulement dans React) : un Responsable ne peut techniquement
pas lire les saisies d'un autre utilisateur, même en modifiant le code
frontend.

## Structure du projet

```
src/
  context/AuthContext.jsx      → session + profil (rôle) de l'utilisateur connecté
  components/ProtectedRoute.jsx → protège une route selon le rôle
  components/Layout.jsx        → sidebar + navbar
  pages/Login.jsx
  pages/admin/                 → écrans Admina
  pages/responsable/           → écrans Responsable
  pages/directeur/              → écran Directeur
  utils/kpiCalc.js             → calcul du statut CONFORME / NON_CONFORME
supabase/
  schema.sql                   → tables + RLS + données initiales
  functions/create-user/       → Edge Function pour créer un utilisateur
```

## Remplacer votre fichier Excel

Chaque table de `schema.sql` correspond à un onglet de votre fichier Excel
actuel (départements, KPI, objectifs, affectations, saisies mensuelles,
plans d'action). Pour importer vos données existantes, le plus simple est
d'exporter chaque onglet en CSV puis de les importer depuis
**Table editor > Import data from CSV** dans Supabase.
